function [Ns,ltr,lte]=five_foldsplit(H_flag)

Ns=[];
i0=1;i1=1;
for i=1:length(H_flag)
    if H_flag(i)==1
        s1(i1)=i;
        i1=i1+1;
    else
        s0(i0)=i;
        i0=i0+1;
    end
end
L1=length(s1);
L0=length(s0);
n1=randperm(L1);
n0=randperm(L0);
long1=ceil(L1/5);
long0=ceil(L0/5);
for K=1:5
n=[];
ntr=[];
nte=[];
    for i=1:5
        if K~=i
            if i==5
                ntr=[ntr ;s1(n1(long1*(i-1)+1:end))'; s0(n0(long0*(i-1)+1:end))'];
            else
                ntr=[ntr ; s1(n1(long1*(i-1)+1:long1*i))' ; s0(n0(long0*(i-1)+1:long0*i))'];
            end
        else
            if i==5
                nte=[s1(n1(long1*(i-1)+1:end))' ; s0(n0(long0*(i-1)+1:end))'];
            else
                nte=[s1(n1(long1*(i-1)+1:long1*i))' ; s0(n0(long0*(i-1)+1:long0*i))'];
            end
        end
    end
    
    n=[ntr ;nte];
    ltr(K)=length(ntr);
    lte(K)=length(nte);
    Ns(:,K)=n;
    clear n
    clear ntr
end
