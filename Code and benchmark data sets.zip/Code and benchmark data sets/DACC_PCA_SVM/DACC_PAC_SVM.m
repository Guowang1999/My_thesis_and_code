clc;
clear;
close all;
tic;
MCC=zeros(1,15);
ACC1=zeros(1,15);
ACC2=zeros(1,15);
forward=zeros(1,15);
negative=zeros(1,15);
 %% Data Import
tt1=fastaread('Supp-S1.txt');
tt2=fastaread('Supp-S2.txt');
[feature1,H_flag1]=DACC(tt1,7);
[feature2,H_flag2]=DACC(tt2,7);
feature=[feature1; feature2];
H_flag=[H_flag1; H_flag2];
%% Open the multithreading
parfor kk=1:30
    %% initialize
    adac1=zeros(1,5);
    adac2=zeros(1,5);
    adaf=zeros(1,5);
    adan=zeros(1,5);
    MC=zeros(1,5);
    %% Randomly generate the training set and test set
    [N ,Ltr ,Lte] =  five_foldsplit(H_flag);
    s1=0;
    s2=0;
    y=PCA(feature);
    y=y(:,1:end);
    sumsl=length(y(:,1));
    matrix=y;
    label=H_flag(:,end);
    for kst=1:5
        n=N(:,kst);
        train_matrix = matrix(n(1:Ltr(kst)),:);
        train_label = label(n(1:Ltr(kst)),:);
        test_matrix = matrix(n(Ltr(kst)+1:end),:);
        test_label = label(n(Ltr(kst)+1:end),:);
        L=test_label;
        %% Data normalization
        [Train_matrix,PS] = mapminmax(train_matrix');
        Train_matrix = Train_matrix';
        Test_matrix = mapminmax('apply',test_matrix',PS);
        Test_matrix = Test_matrix';      
        %% svm creation/training (RBF kernel function)
        [c,g] = meshgrid(-10:0.2:10,-10:0.2:10);
        [m,n] = size(c);
        cg = zeros(m,n);
        eps = 10^(-4);
        v = 5;
        bestc = 0.678;
        bestg = 0.2781;
        bestacc = 0;
        cmd = [' -t 2',' -c ',num2str(bestc),' -g ',num2str(bestg)];
        model = svmtrain(train_label,Train_matrix,cmd);          
        %% SVM simulation test
        [predict_label_1,accuracy_1] = svmpredict(train_label,Train_matrix,model);
        [predict_label_2,accuracy_2] = svmpredict(test_label,Test_matrix,model);
        result_1 = [train_label predict_label_1];
        result_2 = [test_label predict_label_2];
        flag1=0;
        accflag1=0;
        flag2=0;
        accflag2=0;
        for k=1:length(predict_label_2)
            if L(k)==1
                flag1=flag1+1;
                if L(k)==predict_label_2(k)
                    accflag1=accflag1+1;
                end
            else
                flag2=flag2+1;
                if L(k)==predict_label_2(k)
                    accflag2=accflag2+1;
                end
            end
        end
        adac1(kst)=accuracy_1(1); 
        adac2(kst)=accuracy_2(1);
        adaf(kst)=accflag1/flag1*100;
        adan(kst)=accflag2/flag2*100;
        MC(kst)=SMCC(accflag1,accflag2,flag1,flag2)*100;
    end
    ACC1(kk)=mean(adac1);
    ACC2(kk)=mean(adac2);
    forward(kk)=mean(adaf);
    negative(kk)=mean(adan);
    MCC(kk)=mean(MC);
end
fg=max(ACC2);
for i=1:length(ACC2)
    if ACC2(i)==fg
        GS=i;
        break
    end
end
clc
%% Drawing
figure
plot(1:length(ACC2),ACC2,'r-*')
hold on
plot(1:length(forward),forward,'b-*')
hold on
plot(1:length(negative),negative,'g-*')
hold on
plot(1:length(MCC),MCC,'y-*')
grid on
legend('ACC','SP','SN','MCC')
xlabel('times of repetition')
ylabel('Value')
string = {'Comparison of SVM prediction results (RBF kernel function)';
    ['maxacc = ' num2str(max(ACC2)) '%']};
title(string)
toc;
disp('ACC:')
disp(mean(ACC2))
disp('SN:')
disp(mean(negative))
disp('SP:')
disp(mean(forward))
disp('MCC:')
disp(mean(MCC))

