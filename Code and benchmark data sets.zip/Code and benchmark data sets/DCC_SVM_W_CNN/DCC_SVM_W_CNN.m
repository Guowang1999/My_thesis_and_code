clc
clear
warning off
num=zeros(1,1);
Nnum=zeros(2131,1);
tic
%% Data Import
WMCC=zeros(1,1);
WACC1=zeros(1,1);
WACC2=zeros(1,1);
Wforward=zeros(1,1);
Wnegative=zeros(1,1);
tt1=fastaread('Supp-S1.txt');
tt2=fastaread('Supp-S2.txt');
[feature1,H_flag1]=DCC(tt1,6);
[feature2,H_flag2]=DCC(tt2,6);
feature=[feature1; feature2];
H_flag=[H_flag1; H_flag2];
features=SVM_W(feature,H_flag);

for W=100:200
    MCC=zeros(1,1);
    ACC1=zeros(1,1);
    ACC2=zeros(1,1);
    forward=zeros(1,1);
    negative=zeros(1,1);
    for ksks=1:2
        adac1=zeros(1,5);
        adac2=zeros(1,5);
        adaf=zeros(1,5);
        adan=zeros(1,5);
        MC=zeros(1,5);
        wei=W;
        row=1;
        feature=features(:,1:wei*row);
        res=feature;
        lon=length(H_flag);
        [N ,Ltr ,Lte] =  five_foldsplit(H_flag);
        adac=zeros(1,5);
        
        %% Half off cross validation
        for kst=1:5
            n=N(:,kst);
            ltr=Ltr(kst);
            lte=Lte(kst);
            %% Training set - 80% sample
            P_train = res(n(1:ltr),:)';
            T_train = H_flag(n(1:ltr))';
            
            %%  Test set -- 20% samples
            P_test = res(n(ltr+1:end),:)';
            T_test = H_flag(n(ltr+1:end))';
            TrL=length(P_train(1,:));
            TeL=length(P_test(1,:));
            %% Data normalization
            [p_train, ps_input] = mapminmax(P_train,0,1);
            p_test = mapminmax('apply',P_test,ps_input);
            t_train=T_train;
            t_test = T_test;
            
            %% Data tile
            
            p_train =  double(reshape(p_train,wei,row,1,TrL));
            p_test  =  double(reshape(p_test,wei,row,1,TeL));
            t_train =  categorical(t_train)';
            t_test  =  categorical(t_test)';
            
            %% Construct a convolutional neural network
            
            layers = [
                imageInputLayer([wei row 1])
                
                convolution2dLayer([5  1], 16)
                batchNormalizationLayer
                reluLayer
                averagePooling2dLayer([2 1],'Stride',2)
                convolution2dLayer([2 1], 16)
                batchNormalizationLayer
                reluLayer
                
                fullyConnectedLayer(48)
                reluLayer
                dropoutLayer(0.2)
                fullyConnectedLayer(2)
                softmaxLayer
                classificationLayer];
            
            miniBatchSize  = 400;
            
            options = trainingOptions('sgdm',...
                'MiniBatchSize',miniBatchSize,...
                'MaxEpochs',200,...
                'InitialLearnRate',1e-1,...
                'LearnRateSchedule','piecewise',...
                'LearnRateDropFactor',0.01,...
                'LearnRateDropPeriod',400,...
                'Shuffle','every-epoch',...
                'ValidationPatience',Inf,...             %'Plots','training-progress',...
                'Verbose',false);
            
            %%  Train the convolutional neural network
            net = trainNetwork(p_train,t_train,layers,options);
            
            %%  Training set prediction
            t_sim1 =round( predict(net,p_train));
            t_sim2 =round( predict(net,p_test));
            
            T_sim1 = vec2ind(t_sim1')-1;
            T_sim2 = vec2ind(t_sim2')-1;
            
            
            %% Root mean square error RMSE
            error1 = sqrt(sum((T_sim1 - T_train).^2)./TrL);
            error2 = sqrt(sum((T_sim2 - T_test).^2)./TeL);
            %% accuracy
            acc1=sum(T_sim1==T_train)/TrL;
            acc2=sum(T_sim2==T_test)/TeL;
            flag1=0;
            accflag1=0;
            flag2=0;
            accflag2=0;
            L=T_test;
            for k=1:length(T_sim2)
                if L(k)==1
                    flag1=flag1+1;
                    if L(k)==T_sim2(k)
                        accflag1=accflag1+1;
                    end
                else
                    flag2=flag2+1;
                    if L(k)==T_sim2(k)
                        accflag2=accflag2+1;
                    end
                end
            end
            adac1(kst)=acc1*100;
            adac2(kst)=acc2*100;
            adaf(kst)=accflag1/flag1*100;
            adan(kst)=accflag2/flag2*100;
            MC(kst)=SMCC(accflag1,accflag2,flag1,flag2)*100;
        end
        Nnum(:,ksks)=n;
        ACC1(ksks)=mean(adac1);
        ACC2(ksks)=mean(adac2);
        forward(ksks)=mean(adaf);
        negative(ksks)=mean(adan);
        MCC(ksks)=mean(MC);
    end
    WMCC(W-99)=mean(MCC);
    WACC2(W-99)=mean(ACC2);
    Wforward(W-99)=mean(forward);
    Wnegative(W-99)=mean(negative);
end
clc
%% Drawing
figure
plot(1:length(ACC2),ACC2,'r-*')
hold on
plot(1:length(forward),forward,'b-*')
hold on
plot(1:length(negative),negative,'g-*')
hold on
plot(1:length(MCC),MCC,'y-*')
grid on
legend('ACC','SP','SN','MCC')
xlabel('times of repetition')
ylabel('Value')
string = {'Comparison of CNN prediction results';
    ['maxacc = ' num2str(max(ACC2)) '%']};
title(string)


disp('ACC:')
disp(mean(ACC2))
disp('SN:')
disp(mean(negative))
disp('SP:')
disp(mean(forward))
disp('MCC:')
disp(mean(MCC))

plot(WACC2);
toc