function [MC]=SMCC(f0,f1,n0,n1)
TP=f1;
TN=f0;
FP=n1-f1;
FN=n0-f0;
MC=((TP*TN-FP*FN)/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))) ;
end