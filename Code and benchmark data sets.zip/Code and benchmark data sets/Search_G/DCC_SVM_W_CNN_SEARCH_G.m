clc
clear
warning off
num=zeros(1,1);
Nnum=zeros(2131,1);
tic
GN=[];
Gn=zeros(1,15);
for Gs=2:20
    tt1=fastaread('Supp-S1.txt');
    tt2=fastaread('Supp-S2.txt');
    [feature1,H_flag1]=DCC(tt1,Gs);
    [feature2,H_flag2]=DCC(tt2,Gs);
    feature=[feature1; feature2];
    H_flag=[H_flag1; H_flag2];
    features=SVM_W(feature,H_flag);
    for ksks=1:10
        wei=16;
        row=22;
        feature=features(:,1:wei*row);
        res=feature;
        lon=length(H_flag);
        [N ,Ltr ,Lte] =  five_foldsplit(H_flag);
        adac=zeros(1,5);      
         %% Half off cross validation
        for kst=1:5
            n=N(:,kst);
            ltr=Ltr(kst);
            lte=Lte(kst);
             %% Training set - 80% sample
            P_train = res(n(1:ltr),:)';
            T_train = H_flag(n(1:ltr))';
            
             %%  Test set -- 20% samples
            P_test = res(n(ltr+1:end),:)';
            T_test = H_flag(n(ltr+1:end))';
            TrL=length(P_train(1,:));
            TeL=length(P_test(1,:));
             %%  Data normalization
            [p_train, ps_input] = mapminmax(P_train,0,1);
            p_test = mapminmax('apply',P_test,ps_input);
            t_train=T_train;
            t_test = T_test;
            
           %%  Data tile
            
            p_train =  double(reshape(p_train,wei,row,1,TrL));
            p_test  =  double(reshape(p_test,wei,row,1,TeL));
            t_train =  categorical(t_train)';
            t_test  =  categorical(t_test)';
            
             %% Construct a convolutional neural network
            
            layers = [
                imageInputLayer([wei row 1])
                
                convolution2dLayer([5  5], 16)
                batchNormalizationLayer
                reluLayer
                averagePooling2dLayer([2 1],'Stride',2)
                convolution2dLayer([2 2], 16)
                batchNormalizationLayer
                reluLayer
                
                fullyConnectedLayer(48)
                reluLayer
                dropoutLayer(0.2)
                fullyConnectedLayer(2)
                softmaxLayer
                classificationLayer];
            
            miniBatchSize  = 400;%sdgmÿ��Ĵ�С
            
            options = trainingOptions('sgdm',...
                'MiniBatchSize',miniBatchSize,...
                'MaxEpochs',200,...
                'InitialLearnRate',1e-1,...
                'LearnRateSchedule','piecewise',...
                'LearnRateDropFactor',0.01,...%0.01 94.0917 0.1 93.8549
                'LearnRateDropPeriod',400,...
                'Shuffle','every-epoch',...
                'ValidationPatience',Inf,...      %     'Plots','training-progress',...
                'Verbose',false);
            
            %%  Train the convolutional neural network
            net = trainNetwork(p_train,t_train,layers,options);
            
            %%  Training set prediction
            t_sim1 =round( predict(net,p_train));
            t_sim2 =round( predict(net,p_test));
            
            T_sim1 = vec2ind(t_sim1')-1;
            T_sim2 = vec2ind(t_sim2')-1;
            

            %% Root mean square error RMSE
            error1 = sqrt(sum((T_sim1 - T_train).^2)./TrL);
            error2 = sqrt(sum((T_sim2 - T_test).^2)./TeL);
            %% accuracy
            
            acc1=sum(T_sim1==T_train)/TrL;
            acc2=sum(T_sim2==T_test)/TeL;
                      
            [w,p]=max(Gn);
            disp(p);disp(w);
            adac(kst)=acc2*100;
        end
        num(ksks)=mean(adac);
        Nnum(:,ksks)=n;
    end
    Gn(Gs)=mean(num);
    GN=[GN Nnum];
end
[maxG,a] = max(Gn);
clc

%% Drawing
figure
plot(2:length(Gn),Gn(2:end),'r-*');
grid on
legend('ACC')
xlabel('G-Value')
ylabel('ACC')
string = {'Find the best G'};
title(string)

disp('max_G:');
disp(a)
disp('max_acc:');
disp(maxG)
toc