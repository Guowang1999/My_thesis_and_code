function [result_report]=PCA(feature)
A=feature;
a=size(A,1);
b=size(A,2);
SA=zeros(a,b);
for i=1:b
    SA(:,i)=(A(:,i)-mean(A(:,i)))/std(A(:,i));
end
CM=corrcoef(SA);
[V,D]=eig(CM);
for j=1:b
    DS(j,1)=D(b+1-j,b+1-j);
end
for i=1:b
    DS(i,2)=DS(i,1)/sum(DS(:,1));
    DS(i,3)=sum(DS(1:i,1))/sum(DS(:,1));
end
T=0.95;
for k=1:b
    if DS(k,3)>=T
        Com_num=k;
        break;
    end
end
for j=1:Com_num
    PV(:,j)=V(:,b+1-j);
end
new_score=SA*PV;
result_report=new_score;
end