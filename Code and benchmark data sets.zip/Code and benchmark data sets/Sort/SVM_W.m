function [feature2]=SVM_W(data,label)
cmd = ['-t ',num2str(0),' -c ',num2str(1)];
label_set = unique(label);
model = svmtrain(label,data,cmd);
w = (model.SVs)' * model.sv_coef;
cw = w'.^2;
[w_sort,featurelist]=sort(cw,'descend');
feature2 = data(:,featurelist);
end

